package com.softuni.fdmc;

public final class WebConstants {
    private WebConstants() { }

    public static final String ALL_CATS_ATTRIBUTE_NAME = "fdmc.all.cats";
}
