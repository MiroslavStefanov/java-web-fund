package org.softuni.fdmc.data.models;

public enum UserRole {
    ADMIN, USER
}